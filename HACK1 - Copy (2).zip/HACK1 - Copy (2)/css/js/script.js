// Add this function to handle the form submission
function uploadBook() {
    // Get form data
    const title = document.getElementById("bookTitle").value;
    const author = document.getElementById("author").value;
    const subject = document.getElementById("subject").value;
    const courseRelevance = document.getElementById("courseRelevance").value;
    const pdfFile = document.getElementById("pdfFile").files[0];

    // You can perform additional validation here if needed

    // Create a FormData object and append form data
    const formData = new FormData();
    formData.append("title", title);
    formData.append("author", author);
    formData.append("subject", subject);
    formData.append("courseRelevance", courseRelevance);
    formData.append("pdfFile", pdfFile);

    // You can send the formData to the server using fetch or another method
    // For now, let's log the form data to the console
    console.log("Form Data:", formData);
}

