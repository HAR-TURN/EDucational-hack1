// review.js
let currentRating = 0;

function generateStars() {
    const starsContainer = document.getElementById('stars-container');
    starsContainer.innerHTML = '';

    for (let i = 1; i <= 5; i++) {
        const star = document.createElement('i');
        star.classList.add('fas', 'fa-star');
        star.setAttribute('data-rating', i);
        star.addEventListener('click', () => setRating(i));
        starsContainer.appendChild(star);
    }
}

function setRating(rating) {
    currentRating = rating;
    updateRatingDisplay();
}

function updateRatingDisplay() {
    const ratingValue = document.getElementById('rating-value');
    ratingValue.textContent = currentRating;

    const stars = document.querySelectorAll('.stars i');
    stars.forEach(star => {
        const starRating = parseInt(star.getAttribute('data-rating'));
        if (starRating <= currentRating) {
            star.classList.add('rated');
        } else {
            star.classList.remove('rated');
        }
    });
}

function submitReview() {
    const reviewText = document.getElementById('review-text').value;
    if (!reviewText) {
        alert('Please write a review before submitting.');
        return;
    }

    const reviewList = document.getElementById('reviews-list');
    const reviewElement = document.createElement('div');
    reviewElement.classList.add('review');
    reviewElement.innerHTML = `<p><strong>Rating:</strong> ${currentRating}</p><p>${reviewText}</p>`;
    reviewList.appendChild(reviewElement);

    currentRating = 0;
    document.getElementById('review-text').value = '';
    generateStars();
    updateRatingDisplay();
}

generateStars();
updateRatingDisplay();
